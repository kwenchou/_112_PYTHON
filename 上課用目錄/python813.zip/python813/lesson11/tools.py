PI = 3.141592653

def myfunction():
    pass

class MyClass():
    pass